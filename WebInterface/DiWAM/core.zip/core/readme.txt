today queries files:
- state summary
- count_summary
- unsafe_sources
- all_data