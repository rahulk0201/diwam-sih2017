<?php

/*$localhost = 'diwamdb.cl4f9sagnkau.ap-south-1.rds.amazonaws.com';
$username = 'diwam';
$password = 'teamdiwam1996';
$dbname = 'Diwam_stub';*/

$localhost = 'localhost';
$username = 'root';
$password = '';
$dbname = 'diwam';


// $localhost = 'localhost';
// $username = 'id6576030_root';
// $password = 'teamdiwam1996';
// $dbname = 'id6576030_diwamdb';

?>